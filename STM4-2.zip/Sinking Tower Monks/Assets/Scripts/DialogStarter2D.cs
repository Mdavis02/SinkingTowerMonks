﻿using System.Collections.Generic;
using UnityEngine;

public class DialogStarter2D : MonoBehaviour {
	public enum TriggerType { none, autoOnce, triggerEnter, mouseClick, impactEnter }
	public TriggerType actOn = TriggerType.mouseClick;
	public int dialogState = 0;
	public bool destroyOnDialog = false;
	private SpriteRenderer rend = null;
	private Color defaultColor;
	public void Start() {
		if(actOn == TriggerType.mouseClick) {
			rend = gameObject.GetComponent<SpriteRenderer>();
			if(!rend) rend = gameObject.GetComponentInChildren<SpriteRenderer>();
			if(rend) defaultColor = rend.material.color;
			else Debug.Log("Error: " + gameObject.name + " DialogStarter has no solid material to highlight, add a child sprite.");
		}
	}
	public void Update() {
		if(actOn == TriggerType.autoOnce) { StartDialog(); actOn = TriggerType.none; }
	}
	void OnMouseOver() {
		if(rend && actOn == TriggerType.mouseClick && DialogTree2D.I.currentState < 0) {
			if(Input.GetMouseButtonUp(0)) { StartDialog(); rend.material.color = defaultColor; }
			else rend.material.color = (Input.GetMouseButton(0) ? DialogTree2D.I.colorClick : DialogTree2D.I.colorHighlight);
		}
	}
	public void OnMouseExit() {
		if(rend && actOn == TriggerType.mouseClick) rend.material.color = defaultColor;
	}
	public void OnTriggerEnter2D(Collider2D c) {
		if(actOn == TriggerType.triggerEnter) StartDialog();
	}
	public void OnCollisionEnter2D(Collision2D c) {
		if(actOn == TriggerType.impactEnter) StartDialog();
	}
	void StartDialog() {
		if(DialogTree2D.I.currentState < 0) {
			DialogTree2D.I.currentState = dialogState;
			if(destroyOnDialog) Destroy(gameObject);
		}
	}
}
